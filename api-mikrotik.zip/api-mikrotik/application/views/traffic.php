
Download (RX) = <?= formatBytes($rx,2); ?> <br>
Upload (TX) = <?= formatBytes($tx,2); ?> 
