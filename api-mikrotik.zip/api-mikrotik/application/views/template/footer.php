<!-- Main Footer -->
<footer class="main-footer" style="text-align: center;" >
    <strong>Copyright &copy; 2023 <a href="https://www.instagram.com/windy.tkpd/?hl=en">Windy TKPD</a>.</strong>
    TA PSDKU Polinema Kediri.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>